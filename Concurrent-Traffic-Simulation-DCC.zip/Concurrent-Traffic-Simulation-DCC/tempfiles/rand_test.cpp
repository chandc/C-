/* rand example: guess the number */
#include <stdio.h>      /* printf, scanf, puts, NULL */
#include <stdlib.h>     /* srand, rand */
#include <iostream>

int main ()
{
  int iSecret, iGuess;

  /* initialize random seed: */
  srand (2019);

  /* generate secret number between 4 and 6: */
  iSecret = rand() % 2 + 4;

  int i = 0;
  do {
 /* generate secret number between 4 and 6: */
  iSecret = rand() % 3 + 4;
  std::cout << iSecret << std::endl;
  i++;
  } while (i < 100);

  return 0;
}