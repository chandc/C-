#include <string>
#include <iostream>
#include <vector>
#include "util.h" //DCC

#include "ProcessParser.h"

int main()
{

    std::string PID = "2945";

    std::cout << "command line: " << ProcessParser::getCmd(PID) << "\n";

    std::cout << "VM size: " << ProcessParser::getVmSize(PID) << "\n";

    std::cout << "No. of cores: " << ProcessParser::getNumberOfCores() << "\n";

    std::cout << "Sys Uptime " << ProcessParser::getSysUpTime() << "\n";

    std::cout << "%CPU: " << ProcessParser::getCpuPercent(PID) << "\n";

    std::cout << "Process Up Time " << ProcessParser::getProcUpTime(PID) << "\n";

    //std::vector<string> vecPid = ProcessParser::getPidList();
    //for (string p: vecPid)
    //    std::cout<< p << "\n";

    std::cout << "Process User " << ProcessParser::getProcUser(PID) << "\n";

    //std::vector<string> sysCpu = ProcessParser::getSysCpuPercent();
    //for (string p: sysCpu)
    //    std::cout<< p << "\n";

    std::cout << "Number of Processes  " << ProcessParser::getTotalNumberOfProcesses() << "\n";

    std::cout << "Number of Threads  " << ProcessParser::getTotalThreads() << "\n";

    std::cout << "Number of Running Processes: " << ProcessParser::getNumberOfRunningProcesses() << "\n";

    std::cout << "OS Name: " << ProcessParser::getOSName() << "\n";

    std::cout << "Kernel version: " << ProcessParser::getSysKernelVersion() << "\n";

    std::cout << "Does a PID exist? " << ProcessParser::isPidExisting("061760") << "\n";
    std::cout << "Does a PID exist? " << ProcessParser::isPidExisting("2305") << "\n";

    return 0;
}