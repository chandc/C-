#include <string>
#include <iostream>
#include <vector>
#include "ProcessParser.h"



int main() {

std::string PID = "2945";

std::string Cmd = ProcessParser::getCmd(PID);

std::cout << "command line: "<< Cmd << "\n";

std::string vm = ProcessParser::getVmSize(PID);

std::cout << "VM size: " << vm << "\n";

int Core = ProcessParser::getNumberOfCores();

std::cout << "No. of cores: " << Core << "\n";

long int upT = ProcessParser::getSysUpTime();

std::cout << "Sys Uptime " << upT<< "\n";


std::string Cpu = ProcessParser::getCpuPercent(PID);

std::cout << "%CPU: " << Cpu<< "\n";


std::string pUpTime = getProcUpTime(PID);
std::cout << "Process Up Time " << pUpTime << "\n";

std::vector<string> vecPid = ProcessParser::getPidList();
//for (string p: vecPid)
//    std::cout<< p << "\n";

std::string pidUser = ProcessParser::getProcUser(PID);
std::cout << "Process User " << pidUser << "\n";


std::vector<string> sysCpu = ProcessParser::getSysCpuPercent();
for (string p: sysCpu)
    std::cout<< p << "\n";


int numberPro = ProcessParser::getTotalNumberOfProcesses();
std::cout << "Number of Processes  " << numberPro << "\n";
  
int numberTh = ProcessParser::getTotalThreads();
std::cout << "Number of Threads  " << numberTh << "\n";

std::cout << "Number of Running Processes: " << ProcessParser::getNumberOfRunningProcesses() << "\n";

std::cout << "OS Name: " << ProcessParser::getOSName() << "\n";

std::cout << "Kernel version: " << ProcessParser::getSysKernelVersion() << "\n";


return 0;
}